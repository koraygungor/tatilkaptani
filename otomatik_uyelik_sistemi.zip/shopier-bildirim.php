<?php
// shopier-bildirim.php

$order_id = $_POST['platform_order_id']; // Kullanıcının ID'si olabilir
$payment_status = $_POST['status']; // 'success' ise ödeme başarılı

if ($payment_status == 'success') {
    $db = new PDO("mysql:host=localhost;dbname=uyelik_sistemi;charset=utf8", "root", "");

    $sorgu = $db->prepare("UPDATE users SET is_active = 1, membership_expire = DATE_ADD(NOW(), INTERVAL 30 DAY) WHERE id = ?");
    $sorgu->execute([$order_id]);

    file_put_contents("log.txt", "Üyelik açıldı: $order_id\n", FILE_APPEND);
}

http_response_code(200); // Shopier'e OK yanıtı
?>
