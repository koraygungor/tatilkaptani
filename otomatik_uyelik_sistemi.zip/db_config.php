<?php
// db_config.php

try {
    $db = new PDO("mysql:host=localhost;dbname=uyelik_sistemi;charset=utf8", "root", "");
} catch (PDOException $e) {
    die("Veritabanı bağlantısı başarısız: " . $e->getMessage());
}
?>
