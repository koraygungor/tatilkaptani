<?php
// login.php
include("db_config.php");
session_start();

$username = $_POST['username'];
$password = $_POST['password'];

$stmt = $db->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
$stmt->execute([$username, $password]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user) {
    $_SESSION['user_id'] = $user['id'];
    if ($user['is_active'] && strtotime($user['membership_expire']) > time()) {
        echo "Hoş geldin kaptan, içerikler senin!";
    } else {
        echo "Üyeliğin sona ermiş. Yenilemek ister misin?";
    }
} else {
    echo "Kullanıcı adı veya şifre hatalı.";
}
?>
