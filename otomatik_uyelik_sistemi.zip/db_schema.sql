
CREATE DATABASE IF NOT EXISTS uyelik_sistemi;
USE uyelik_sistemi;

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    is_active TINYINT(1) DEFAULT 0,
    membership_expire DATETIME DEFAULT NULL
);
